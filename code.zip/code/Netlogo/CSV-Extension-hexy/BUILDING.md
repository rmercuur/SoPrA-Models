## Building

Run `sbt package`.

If compilation succeeds, `csv.jar` will be created. This file and `commons-csv-1.0.jar` should then be placed in a folder named `csv` in your NetLogo `extensions` directory.
