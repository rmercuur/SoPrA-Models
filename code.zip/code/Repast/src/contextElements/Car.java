package contextElements;
public class Car extends Resource{

}
