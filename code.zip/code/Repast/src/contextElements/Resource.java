package contextElements;

import socialPracticeElements.ContextElement;

public class Resource extends ContextElement {

}
