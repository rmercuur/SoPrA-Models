package contextElements;
public class Bike extends Resource {

}
