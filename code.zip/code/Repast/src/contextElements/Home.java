package contextElements;

public class Home extends Location {

}
