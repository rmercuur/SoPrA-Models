package contextElements;

public class Work extends Location{

}
