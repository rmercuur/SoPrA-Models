package socialPracticeElements;

public class Value {
	String name;
	public  Value(String name) {
		this.name = name;
	}
}
